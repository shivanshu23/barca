 package com.employee.lnd.jdbc.model;

public class User {

       private String userLogin;
       private String userPass;
   	private String name;
    private String role;
	private String salary;
    private String contactNumber;
    private String employeeId;
    private String designation;
	private String panNumber;
    private String adhaarCardNumber;
    private String bankAccountNumber;
       public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getAdhaarCardNumber() {
		return adhaarCardNumber;
	}
	public void setAdhaarCardNumber(String adhaarCardNumber) {
		this.adhaarCardNumber = adhaarCardNumber;
	}
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

      public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}

       public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
       public User(String userLogin, String name, String contactNumber,
			String employeeId, String designation, String panNumber,
			String adhaarCardNumber, String bankAccountNumber) {
		super();
		this.userLogin = userLogin;
		this.name = name;
		this.contactNumber = contactNumber;
		this.employeeId = employeeId;
		this.designation = designation;
		this.panNumber = panNumber;
		this.adhaarCardNumber = adhaarCardNumber;
		this.bankAccountNumber = bankAccountNumber;
	}
	public User(String userLogin, String userPass) {
              super();
              this.userLogin = userLogin;
              this.userPass = userPass;
              
       }
       public User(String name,String userLogin, String userPass) {
              super();
              this.name=name;
              this.userLogin = userLogin;
              this.userPass = userPass;
              
       }
       public User(String name,String userLogin, String userPass,String role) {
           super();
           this.name=name;
           this.userLogin = userLogin;
           this.userPass = userPass;
           this.role = role;
    }
       public User() {
              super();
              // TODO Auto-generated constructor stub
       }

       public String getUserLogin() {
              return userLogin;
       }

       public void setUserLogin(String userLogin) {
              this.userLogin = userLogin;
       }

       public String getUserPass() {
              return userPass;
       }

       public void setUserPass(String userPass) {
              this.userPass = userPass;
       }

       public String getName() {
              return name;
       }

       public void setName(String name) {
              this.name = name;
       }
       public String getRole() {
           return role;
    }

    public void setRole(String role) {
           this.role = role;
    }
       @Override
	public String toString() {
		return "User [userLogin=" + userLogin + ", userPass=" + userPass
				+ ", name=" + name + ", role=" + role + ", contactNumber="
				+ contactNumber + ", employeeId=" + employeeId
				+ ", designation=" + designation + ", salary=" + salary
				+ ", panNumber=" + panNumber + ", adhaarCardNumber="
				+ adhaarCardNumber + ", bankAccountNumber=" + bankAccountNumber
				+ "]";
	}

}

