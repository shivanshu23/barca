package com.employee.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.lnd.jdbc.dao.UserDao;
import com.employee.lnd.jdbc.dao.impl.UserDaoImpl;
import com.employee.lnd.jdbc.model.User;

/**
 * Servlet implementation class update
 */
@WebServlet("/update")
public class update extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6901613958523540960L;
	private UserDao testDao = new UserDaoImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String contact = (String) request.getParameter("contact");
        String pan = (String) request.getParameter("pan");
        String adhar = (String) request.getParameter("adhar");
        String bank = (String) request.getParameter("bank");
        HttpSession session = request.getSession(true);
        User userLogin1=(User) session.getAttribute("user");
        System.out.println("++++++++++++++++++++++++++++++++");
        String userLogin=userLogin1.getName();
        System.out.println("+++++++++++++++++++++++++++++++++");
       User check=new User();
       check.setUserLogin(userLogin);
       check.setContactNumber(contact);
       check.setPanNumber(pan);
       check.setAdhaarCardNumber(adhar);
       check.setBankAccountNumber(bank);
       System.out.println(check);
        testDao.updateDetail(check);
        RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/updated.jsp");

        dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
