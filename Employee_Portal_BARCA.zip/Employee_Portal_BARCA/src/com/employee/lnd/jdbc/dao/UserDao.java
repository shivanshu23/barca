package com.employee.lnd.jdbc.dao;

import java.sql.SQLException;
import java.util.List;

import com.employee.lnd.jdbc.model.User;

public interface UserDao {

       void save(User user);
       
       void save1(User user)throws SQLException;

       void update(String userId, User newUSer);

       void remove(String userId);

       User findUser(String userId, String userPass);

       List<User> allUsers() throws SQLException;
       
      public User getDetail(String userId);
       
       
       User findUser(String userId);
        void saveSal(User user);
        void updateDetail(User user);
}

