package com.employee.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.lnd.jdbc.dao.UserDao;
import com.employee.lnd.jdbc.dao.impl.UserDaoImpl;
import com.employee.lnd.jdbc.model.User;

/**
 * Servlet implementation class viewDetails
 */
@WebServlet("/viewDetails")
public class viewDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDao = new UserDaoImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(true);
		User userId=(User) session.getAttribute("user");
		
		String salary=userId.getSalary();
		System.out.println(salary);
		request.setAttribute("salary", salary);
		User allDetails=null;
		System.out.println(userId.getName());		
		UserDao check =new UserDaoImpl();
		allDetails=check.getDetail(userId.getName());
		System.out.println(allDetails);
		session.setAttribute("allDetails", allDetails);
		// Forward to /WEB-INF/views/productListView.jsp
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/viewProfile.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
