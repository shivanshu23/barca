package com.employee.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.lnd.jdbc.dao.UserDao;
import com.employee.lnd.jdbc.dao.impl.UserDaoImpl;
import com.employee.lnd.jdbc.model.User;

/**
 * Servlet implementation class GoToViewProfile
 */
@WebServlet("/GoToViewProfile")
public class GoToViewProfile extends HttpServlet {
	
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 7946256137243054955L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public GoToViewProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		User check=null;
		UserDao check1=new UserDaoImpl();
		
	//	check=check1.findUser(userId, userPass)
		
		
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/viewDetails");

        dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
