package com.employee.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.lnd.jdbc.dao.UserDao;
import com.employee.lnd.jdbc.dao.impl.UserDaoImpl;
import com.employee.lnd.jdbc.model.User;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {

	/**
                * 
                 */
	private static final long serialVersionUID = 3842502829549545104L;
	private UserDao userDao = new UserDaoImpl();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Validate() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		System.out.println(userName);
		System.out.println(password);
		
		//USER MODEL OBJECT
		User user = null;
		boolean hasError = false;
		String errorString = null;

		if (userName == null || password == null || userName.length() == 0
				|| password.length() == 0) {
			hasError = true;
			errorString = "Required username and password!";
		} else {

			user = userDao.findUser(userName, password);
			System.out.println(user);
			if (user == null) {
				hasError = true;
				errorString = "User Name or password invalid";
			}

		}
		System.out.println(errorString);
		// If error, forward to /WEB-INF/views/_login.jsp
		if (hasError) {
			System.out.println("in if");
			user = new User();
			user.setUserLogin(userName);
			user.setUserPass(password);

			// Store information in request attribute, before forward.
			request.setAttribute("errorString", errorString);
			request.setAttribute("user", user);

			// Forward to /WEB-INF/views/_login.jsp
			getServletContext().getRequestDispatcher(
					"/WEB-INF/views/login_signup.jsp").forward(request,
					response);
		}

		// If no error
		// Store user information in Session
		// And redirect to correct home page.
		else {
			System.out.println("in else");
			HttpSession session = request.getSession(true);
			session.setAttribute("userIs", user.getUserLogin());
			System.out.println("Session Started");
			if (user.getRole().equalsIgnoreCase("admin")) {
				// Redirect to userInfo page.
				System.out.println("in else if");
				RequestDispatcher dispatcher = this.getServletContext()
						.getRequestDispatcher("/WEB-INF/views/adminLogin.jsp");

				dispatcher.forward(request, response);

			} // else
			else {
				System.out.println("in else else");
				session.setAttribute("user", user);
				
				RequestDispatcher dispatcher = this.getServletContext()
						.getRequestDispatcher("/WEB-INF/views/afterLogin.jsp");

				dispatcher.forward(request, response);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
