package com.employee.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.lnd.jdbc.dao.UserDao;
import com.employee.lnd.jdbc.dao.impl.UserDaoImpl;
import com.employee.lnd.jdbc.model.User;

/**
 * Servlet implementation class AddDetailsServlet
 */
@WebServlet("/AddDetailsServlet")
public class AddDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String u = (String) request.getParameter("u");
        String e = (String) request.getParameter("eid");
        String c = (String) request.getParameter("c");
        String eid = (String) request.getParameter("e");
        String d = (String) request.getParameter("d");
        String p = (String) request.getParameter("p");
        String a = (String) request.getParameter("a");
        String b = (String) request.getParameter("b");
//        String s = (String) request.getParameter("s");

        System.out.println("++++++++++++++++++++++++++++++++");

        System.out.println("+++++++++++++++++++++++++++++++++");
       User check=new User();
       
       check.setName(u);
       check.setEmployeeId(e);
       check.setContactNumber(c);
       check.setUserLogin(eid);
       check.setDesignation(d);
       check.setPanNumber(p);
       check.setAdhaarCardNumber(a);
       check.setBankAccountNumber(b);
//       check.setSalary(s);
        
       UserDao us=new UserDaoImpl();
       try{
    	   us.save1(check);

           RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/adddetails.jsp");

           dispatcher.forward(request, response);
    	   
       }
       catch(Exception ef)
       {
    	   RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/adddetails.jsp");

           dispatcher.forward(request, response);
       }
       

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
